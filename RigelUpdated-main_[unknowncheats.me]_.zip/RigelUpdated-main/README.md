#rigel learning purposes only
