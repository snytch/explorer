#pragma once
#include <string>

namespace TimeH {
	std::string getHourMinutesSeconds();
	float currentTimeMS();
}