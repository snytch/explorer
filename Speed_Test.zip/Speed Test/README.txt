***** This tool is run from your RADAR (2nd) PC *****

1) (Optional) Install the VC 2015-2022 Redist x64 Package @ https://aka.ms/vs/17/release/vc_redist.x64.exe

2) Run 'lone-dma-test.exe' to start the DMA Test Application.

3) If there are any errors/failures, see the DMA Setup Guide for troubleshooting, and/or contact Support for assistance.